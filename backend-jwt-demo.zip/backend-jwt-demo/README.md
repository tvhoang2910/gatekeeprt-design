# Backend JWT Demo

Backend demo với Node.js, Express và JWT authentication, được thiết kế để kết nối với React Vite frontend.

## Tính năng

- ✅ JWT Authentication (đăng ký, đăng nhập, logout)
- ✅ Protected routes với middleware authentication
- ✅ CORS được cấu hình cho Vite dev server
- ✅ Bcrypt để hash password
- ✅ In-memory user database (mock data)

## Cài đặt

```bash
cd backend-jwt-demo
npm install
```

## Chạy server

```bash
# Development mode (auto-reload với Node 18+)
npm run dev

# Production mode
npm start
```

Server sẽ chạy trên `http://localhost:3000`

## Test Credentials

- Email: `admin@example.com`, Password: `admin123`
- Email: `user@example.com`, Password: `user123`

## API Endpoints

### Public Routes

#### `GET /`
Health check và thông tin API

#### `POST /api/auth/register`
Đăng ký user mới
```json
{
  "email": "test@example.com",
  "password": "password123",
  "name": "Test User"
}
```

Response:
```json
{
  "message": "User registered successfully",
  "token": "jwt_token_here",
  "user": {
    "id": 3,
    "email": "test@example.com",
    "name": "Test User"
  }
}
```

#### `POST /api/auth/login`
Đăng nhập
```json
{
  "email": "admin@example.com",
  "password": "admin123"
}
```

Response:
```json
{
  "message": "Login successful",
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "email": "admin@example.com",
    "name": "Admin User"
  }
}
```

### Protected Routes (yêu cầu JWT token)

Gửi token trong header: `Authorization: Bearer <token>`

#### `GET /api/auth/profile`
Lấy thông tin user hiện tại

#### `GET /api/users`
Lấy danh sách tất cả users (demo only)

#### `POST /api/auth/logout`
Logout (xóa token ở client)

## Environment Variables

Tạo file `.env`:

```
PORT=3000
JWT_SECRET=your-secret-key-change-this-in-production
JWT_EXPIRES_IN=24h
```

## Kết nối với React Frontend

Frontend cần:
1. Cập nhật `baseURL` trong axios instance thành `http://localhost:3000`
2. Gửi token trong header: `Authorization: Bearer ${token}`
3. Lưu token sau khi login (localStorage hoặc Redux store)

## Bảo mật

⚠️ **Lưu ý**: Đây là demo project cho mục đích học tập:
- Sử dụng in-memory database (không persistent)
- Mock passwords đã được hash sẵn
- Cần thay đổi JWT_SECRET trong production
- Nên sử dụng database thật (MongoDB, PostgreSQL, etc.)
- Nên thêm rate limiting, validation, và security middleware

## Tech Stack

- Node.js + Express
- JWT (jsonwebtoken)
- Bcrypt (password hashing)
- CORS
- dotenv
